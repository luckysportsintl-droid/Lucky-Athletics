"use client";
import { useEffect, useRef, useState } from 'react';
import type { Category, Design } from '@/lib/catalog';
import { mockupPath, templatePath } from '@/lib/mockup-paths';

export function MockupImage({category,design,sizes='(max-width: 680px) 46vw, (max-width: 960px) 30vw, 25vw',eager=false}:{category:Category;design:Design;sizes?:string;eager?:boolean}) {
  return <img className="finished-mockup" src={mockupPath(category,design,640)}
    srcSet={`${mockupPath(category,design,320)} 320w, ${mockupPath(category,design,640)} 640w`}
    sizes={sizes} width={640} height={720} loading={eager?'eager':'lazy'} decoding="async"
    alt={`${category.name} — ${design.name} pattern applied to the finished product`}/>;
}
const images=new Map<string,Promise<HTMLImageElement>>();
function loadImage(src:string) {
  let pending=images.get(src);
  if(!pending){pending=new Promise<HTMLImageElement>((resolve,reject)=>{
    const image=new Image(); image.onload=()=>resolve(image);image.onerror=()=>{images.delete(src);reject(new Error('Image unavailable'));};image.src=src;
  }); images.set(src,pending);}
  return pending;
}
export function ColorMockup({category,design}:{category:Category;design:Design}) {
  const ref=useRef<HTMLCanvasElement>(null);
  const [status,setStatus]=useState<'loading'|'ready'|'error'>('loading');
  useEffect(()=>{
    let current=true;setStatus('loading');
    Promise.all([import('@/lib/mockup-renderer'),loadImage(templatePath(category)),design.texture?loadImage(design.texture):Promise.resolve(undefined)])
      .then(([renderer,image,artwork])=>{
        if(!current||!ref.current)return;
        const factory=(width:number,height:number)=>{const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;return canvas;};
        const template=renderer.prepareTemplate(image,category,factory);
        renderer.renderMockup(ref.current,template,category,design,factory,artwork);
        setStatus('ready');
      }).catch(()=>{if(current)setStatus('error');});
    return()=>{current=false;};
  },[category,design]);
  return <><canvas ref={ref} width={640} height={720} className={`finished-mockup color-mockup ${status==='ready'?'is-ready':''}`} role="img" aria-label={`${category.name} ${design.name} in the selected colors`} aria-hidden={status!=='ready'}/>
    {status!=='ready'&&<span className="mockup-status" role="status">{status==='error'?'Color preview unavailable. Showing original design.':'Preparing your colors…'}</span>}</>;
}
