"use client";
import {useEffect,useRef} from 'react';
import * as THREE from 'three';
import {createProduct,productScene,type ProductAsset} from '@/lib/product-mesh';
import type {Category,Design} from '@/lib/catalog';

type Props={category:Category;design:Design;paused:boolean;cinematic?:boolean;secondary?:Category;onError:()=>void;onReady?:()=>void};
export default function ProductStage(props:Props){
 const host=useRef<HTMLDivElement>(null),current=useRef(props),update=useRef<(()=>void)|null>(null);current.current=props;
 useEffect(()=>{update.current?.();},[props.category,props.design,props.paused,props.secondary]);
 useEffect(()=>{
  const node=host.current;if(!node)return;let renderer:THREE.WebGLRenderer;
  try{renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power',failIfMajorPerformanceCaveat:true});}catch{current.current.onError();return;}
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,window.innerWidth<700?1.25:1.6));renderer.setClearColor(0x000000,0);renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.outputColorSpace=THREE.SRGBColorSpace;node.appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
  const {scene,camera}=productScene();const actor=new THREE.Group(),support=new THREE.Group();scene.add(actor,support);
  let asset:ProductAsset|undefined,second:ProductAsset|undefined,activeKey='',disposed=false,visible=true,phase=0,last=0,entrance=1,slow=0;
  const rebuild=()=>{const p=current.current;const key=[p.category.id,p.design.id,p.design.primary,p.design.accent,p.design.trim,p.secondary?.id].join('|');if(key===activeKey)return;activeKey=key;if(asset){actor.remove(asset.group);asset.dispose();}asset=createProduct(p.category,p.design);actor.add(asset.group);if(second){support.remove(second.group);second.dispose();second=undefined;}if(p.cinematic&&p.secondary){second=createProduct(p.secondary,{...p.design,motif:'chevron',primary:'#f0eee8',accent:'#eb2439',trim:'#191b20'},384);support.add(second.group);support.position.set(-1.28,-.02,-1.45);support.scale.setScalar(.73);support.rotation.y=.35;}entrance=p.paused?1:0;};
  const draw=(time:number)=>{if(disposed)return;const dt=last?Math.min((time-last)/1000,.06):.016;last=time;const p=current.current;if(!p.paused&&p.cinematic)phase+=dt;entrance=Math.min(1,entrance+dt*2.4);const eased=1-(1-entrance)**3;actor.position.x=p.cinematic?.35+(1-eased)*1.2:0;actor.position.y=p.cinematic&&!p.paused?Math.sin(phase*.85)*.035:0;actor.rotation.set(0,-.24,p.cinematic?-.035:0);support.rotation.y=.35;renderer.render(scene,camera);if(dt>.046&&++slow>90){renderer.setPixelRatio(1);slow=-10000;}};
  const sync=()=>{last=0;renderer.setAnimationLoop(visible&&!document.hidden&&current.current.cinematic&&!current.current.paused?draw:null);draw(0);};
  update.current=()=>{rebuild();sync();};
  const resize=()=>{const r=node.getBoundingClientRect();if(!r.width||!r.height)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.position.z=current.current.cinematic?(r.width<400?7.0:6.1):(r.width<350?6.1:5.5);camera.updateProjectionMatrix();draw(0);};
  const ro=new ResizeObserver(resize);ro.observe(node);const io=new IntersectionObserver(([e])=>{visible=e.isIntersecting;sync();},{threshold:.01});io.observe(node);
  const lost=(e:Event)=>{e.preventDefault();current.current.onError();};const visibility=()=>sync();
  document.addEventListener('visibilitychange',visibility);renderer.domElement.addEventListener('webglcontextlost',lost);
  try{rebuild();resize();sync();current.current.onReady?.();}catch{current.current.onError();}
  document.fonts.ready.then(()=>{if(!disposed){activeKey='';rebuild();draw(0);}});
  return()=>{disposed=true;update.current=null;renderer.setAnimationLoop(null);ro.disconnect();io.disconnect();document.removeEventListener('visibilitychange',visibility);renderer.domElement.removeEventListener('webglcontextlost',lost);asset?.dispose();second?.dispose();renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();};
 },[]);
 return <div className={`product-stage ${props.cinematic?'cinematic-stage':''}`} ref={host} role="img" aria-label={`${props.category.name} ${props.design.name} fabric-textured 3D concept, fixed studio view.`}/>;
}
