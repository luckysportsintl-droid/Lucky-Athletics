"use client";
import { Component, type ReactNode } from "react";
export default class ViewerBoundary extends Component<{children:ReactNode;onError:()=>void},{failed:boolean}> {
  state = {failed:false};
  static getDerivedStateFromError() {return {failed:true};}
  componentDidCatch() {this.props.onError();}
  render(){return this.state.failed?<img className="lab-fallback" src="/images/hero-jersey.webp" alt="Lucky Athletics uniform concept"/>:this.props.children;}
}
