"use client";
import {useEffect,useRef} from 'react';
import * as THREE from 'three';
import {createProduct,productScene,type ProductAsset} from '@/lib/product-mesh';
import {designs,type Category} from '@/lib/catalog';

/** One WebGL context for all 24 tiles; only visible tiles are drawn. */
export default function DesignGridCanvas({category,paused,onReady,onError}:{category:Category;paused:boolean;onReady:()=>void;onError:()=>void}){
 const host=useRef<HTMLDivElement>(null),state=useRef({paused,onReady,onError});state.current={paused,onReady,onError};const syncRef=useRef<(()=>void)|null>(null);
 useEffect(()=>{syncRef.current?.();},[paused]);
 useEffect(()=>{
  const node=host.current,parent=node?.parentElement;if(!node||!parent)return;
  let renderer:THREE.WebGLRenderer;try{renderer=new THREE.WebGLRenderer({alpha:true,antialias:false,powerPreference:'low-power',failIfMajorPerformanceCaveat:true});}catch{state.current.onError();return;}
  renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;renderer.setClearColor(0x000000,0);renderer.setScissorTest(true);node.appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
  const tiles=Array.from(parent.querySelectorAll<HTMLElement>('[data-design-art]'));const assets:ProductAsset[]=[];
  const scenes=designs.map(design=>{const context=productScene();const asset=createProduct(category,design,256);context.scene.add(asset.group);assets.push(asset);return {...context,asset};});
  let disposed=false,visible=true;
  const draw=(time=0)=>{if(disposed)return;const bounds=parent.getBoundingClientRect();renderer.setScissor(0,0,bounds.width,bounds.height);renderer.clear();tiles.forEach((tile,i)=>{const rect=tile.getBoundingClientRect();if(!rect.width||rect.bottom<0||rect.top>window.innerHeight)return;const left=rect.left-bounds.left,bottom=bounds.bottom-rect.bottom;renderer.setViewport(left,bottom,rect.width,rect.height);renderer.setScissor(left,bottom,rect.width,rect.height);const {camera,scene,asset}=scenes[i];camera.aspect=rect.width/rect.height;camera.position.z=5.6;camera.updateProjectionMatrix();asset.group.rotation.y=-.24;renderer.render(scene,camera);});};
  const resize=()=>{const r=parent.getBoundingClientRect();renderer.setPixelRatio(Math.min(1,4096/Math.max(r.width,r.height)));renderer.setSize(r.width,r.height,false);draw();};
  const sync=()=>{if(visible&&!document.hidden)draw();};syncRef.current=sync;
  const ro=new ResizeObserver(resize);ro.observe(parent);const io=new IntersectionObserver(([e])=>{visible=e.isIntersecting;sync();});io.observe(parent);let frame=0;const scroll=()=>{if(!visible||frame)return;frame=requestAnimationFrame(()=>{frame=0;draw();});};const lost=(e:Event)=>{e.preventDefault();state.current.onError();};document.addEventListener('visibilitychange',sync);window.addEventListener('scroll',scroll,{passive:true});renderer.domElement.addEventListener('webglcontextlost',lost);
  try{resize();sync();state.current.onReady();}catch{state.current.onError();}
  return()=>{disposed=true;cancelAnimationFrame(frame);syncRef.current=null;renderer.setAnimationLoop(null);ro.disconnect();io.disconnect();document.removeEventListener('visibilitychange',sync);window.removeEventListener('scroll',scroll);renderer.domElement.removeEventListener('webglcontextlost',lost);assets.forEach(a=>a.dispose());renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();};
 },[category]);
 return <div className="design-grid-canvas" ref={host} aria-hidden="true"/>;
}
