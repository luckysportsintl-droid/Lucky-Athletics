"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

type Props = { color: string; paused: boolean; angle: number; onError: () => void };

/** A self-contained concept jersey. No remote model, texture CDN, or API needed. */
export default function UniformViewer({ color, paused, angle, onError }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const controls = useRef({ color, paused, angle, onError });
  const update = useRef<(() => void) | null>(null);
  controls.current = { color, paused, angle, onError };
  useEffect(() => { update.current?.(); }, [color, paused, angle]);

  useEffect(() => {
    const container = host.current;
    if (!container) return;
    let disposed = false;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: "low-power", failIfMajorPerformanceCaveat: true }); }
    catch { controls.current.onError(); return; }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, window.innerWidth < 700 ? 1.25 : 1.6));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.domElement.setAttribute("aria-hidden", "true");
    container.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(36, 1, .1, 40);
    camera.position.set(0, .1, 5.1);
    camera.lookAt(0, -.05, 0);
    scene.add(new THREE.HemisphereLight(0xffffff, 0x5d5264, 2.1));
    const key = new THREE.DirectionalLight(0xffffff, 4.8); key.position.set(-3, 4, 5); scene.add(key);
    const rim = new THREE.DirectionalLight(0xffc5c9, 3.5); rim.position.set(4, 2, -2); scene.add(rim);
    const fill = new THREE.DirectionalLight(0xdbe7ff, 1.8); fill.position.set(2, -1, 4); scene.add(fill);

    const jersey = new THREE.Group(); scene.add(jersey);
    const textures: THREE.Texture[] = [];
    const mats: THREE.Material[] = [];
    const geometries: THREE.BufferGeometry[] = [];
    const frontCanvas = document.createElement("canvas"), backCanvas = document.createElement("canvas");
    frontCanvas.width = backCanvas.width = 1024; frontCanvas.height = backCanvas.height = 1024;
    const frontTexture = new THREE.CanvasTexture(frontCanvas), backTexture = new THREE.CanvasTexture(backCanvas);
    for(const texture of [frontTexture, backTexture]) { texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = Math.min(4,renderer.capabilities.getMaxAnisotropy()); textures.push(texture); }
    const drawTexture = (canvas: HTMLCanvasElement, back: boolean) => {
      const ctx = canvas.getContext("2d")!;
      ctx.fillStyle = "#252529"; ctx.fillRect(0,0,1024,1024);
      ctx.fillStyle = controls.current.color;
      ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(132,0);ctx.lineTo(95,600);ctx.lineTo(180,1024);ctx.lineTo(0,1024);ctx.fill();
      ctx.beginPath();ctx.moveTo(1024,0);ctx.lineTo(892,0);ctx.lineTo(929,600);ctx.lineTo(844,1024);ctx.lineTo(1024,1024);ctx.fill();
      ctx.strokeStyle="#d7d7d7";ctx.lineWidth=4;
      ctx.beginPath();ctx.moveTo(143,0);ctx.lineTo(106,600);ctx.lineTo(191,1024);ctx.stroke();
      ctx.beginPath();ctx.moveTo(881,0);ctx.lineTo(918,600);ctx.lineTo(833,1024);ctx.stroke();
      ctx.textAlign="center";ctx.textBaseline="middle";
      ctx.fillStyle="#f7f7f3";ctx.font="800 89px 'Barlow Condensed', Impact, sans-serif";
      ctx.fillText(back ? "YOUR TEAM" : "LUCKY",512,310);
      ctx.font="800 410px 'Barlow Condensed', Impact, sans-serif";ctx.lineWidth=3;ctx.strokeStyle="#f4f4f1";
      ctx.strokeText("07",512,585);ctx.fillText("07",512,585);
      ctx.font="700 22px Manrope, sans-serif";ctx.fillStyle="#a2a2a7";ctx.fillText("A T H L E T I C S",512,825);
      // Repeated weave perforations make the material read as technical knit.
      for(let y=0;y<1024;y+=9)for(let x=(y%18===0?0:4);x<1024;x+=9){ctx.fillStyle="rgba(0,0,0,.23)";ctx.beginPath();ctx.ellipse(x,y,1.4,2.1,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="rgba(255,255,255,.045)";ctx.fillRect(x+2,y+2,1,3);}
      ctx.strokeStyle="#ffffff22";ctx.lineWidth=2;ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(0,973);ctx.lineTo(1024,973);ctx.stroke();ctx.setLineDash([]);
    };
    drawTexture(frontCanvas,false);drawTexture(backCanvas,true);
    const materialFront = new THREE.MeshStandardMaterial({map:frontTexture,roughness:.88,metalness:.03,side:THREE.DoubleSide});
    const materialBack = new THREE.MeshStandardMaterial({map:backTexture,roughness:.88,metalness:.03,side:THREE.DoubleSide});
    const trimMaterial = new THREE.MeshStandardMaterial({color,roughness:.7,side:THREE.DoubleSide});
    mats.push(materialFront,materialBack,trimMaterial);

    function surface(u:number,v:number,back=false) {
      const a=Math.abs(u);
      // Neck scoop, shoulder straps, and open armholes in a continuous shell.
      const top=a<.36 ? .72+.48*Math.pow(a/.36,2) : a<.69 ? 1.2-.06*(a-.36)/.33 : 1.14-.82*Math.pow((a-.69)/.31,.65);
      const y=-1.25+(top+1.25)*v;
      const width=.73+.075*Math.sin(v*Math.PI)-.03*Math.sin(v*Math.PI*2);
      const x=u*width;
      const depth=(.29+.025*Math.sin(v*Math.PI))*Math.sqrt(Math.max(0,1-u*u));
      const folds=.014*Math.sin(u*26+v*6)*Math.sin(Math.PI*v)*(Math.pow(a,2)+.15)+.009*Math.sin(v*30+u*4)*(1-v);
      return new THREE.Vector3(x,y,(depth+folds)*(back?-1:1));
    }
    for(const back of [false,true]) {
      const cols=64,rows=64,positions:number[]=[],uv:number[]=[],indices:number[]=[];
      for(let j=0;j<=rows;j++) for(let i=0;i<=cols;i++) {const u=i/cols*2-1,v=j/rows,p=surface(u,v,back);positions.push(p.x,p.y,p.z);uv.push(back?1-i/cols:i/cols,v);}
      for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const a=j*(cols+1)+i,b=a+1,c=a+cols+1,d=c+1;if(back)indices.push(a,c,b,b,c,d);else indices.push(a,b,c,b,d,c);}
      const geo=new THREE.BufferGeometry();geo.setAttribute("position",new THREE.Float32BufferAttribute(positions,3));geo.setAttribute("uv",new THREE.Float32BufferAttribute(uv,2));geo.setIndex(indices);geo.computeVertexNormals();geometries.push(geo);
      jersey.add(new THREE.Mesh(geo,back?materialBack:materialFront));
    }
    function seam(points:THREE.Vector3[],radius=.013,mat:THREE.Material=trimMaterial) {
      const geo=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),Math.max(24,points.length*2),radius,5,false);geometries.push(geo);jersey.add(new THREE.Mesh(geo,mat));
    }
    // Top opening trim: neck and arms remain genuinely open for the rear view.
    for(const back of [false,true]) { const points=[];for(let i=0;i<=64;i++)points.push(surface(i/32-1,1,back));seam(points,.023); const hem=[];for(let i=0;i<=48;i++)hem.push(surface(i/24-1,.014,back));seam(hem,.009); }
    for(const sign of [-1,1]) {
      const positions:number[]=[],indices:number[]=[];
      for(let i=0;i<=16;i++)for(let j=0;j<=12;j++){const u=sign*(.36+i/16*.33),f=surface(u,1),b=surface(u,1,true),t=j/12;positions.push(f.x,f.y+.022*Math.sin(Math.PI*t),f.z*(1-t)+b.z*t);}
      for(let i=0;i<16;i++)for(let j=0;j<12;j++){const a=i*13+j;indices.push(a,a+1,a+13,a+1,a+14,a+13);}
      const geo=new THREE.BufferGeometry();geo.setAttribute("position",new THREE.Float32BufferAttribute(positions,3));geo.setIndex(indices);geo.computeVertexNormals();geometries.push(geo);jersey.add(new THREE.Mesh(geo,trimMaterial));
    }
    const pedestalGeo=new THREE.CylinderGeometry(1.2,1.25,.035,64);geometries.push(pedestalGeo);
    const pedestalMat=new THREE.MeshStandardMaterial({color:0x222225,roughness:.8,metalness:.3});mats.push(pedestalMat);
    const pedestal=new THREE.Mesh(pedestalGeo,pedestalMat);pedestal.position.y=-1.57;scene.add(pedestal);
    const ringGeo=new THREE.TorusGeometry(1.22,.007,6,90);geometries.push(ringGeo);const ringMat=new THREE.MeshBasicMaterial({color});mats.push(ringMat);const ring=new THREE.Mesh(ringGeo,ringMat);ring.rotation.x=Math.PI/2;ring.position.y=-1.545;scene.add(ring);
    const shadowCanvas=document.createElement("canvas");shadowCanvas.width=shadowCanvas.height=64;const sctx=shadowCanvas.getContext("2d")!;const gradient=sctx.createRadialGradient(32,32,1,32,32,32);gradient.addColorStop(0,"rgba(0,0,0,.6)");gradient.addColorStop(1,"rgba(0,0,0,0)");sctx.fillStyle=gradient;sctx.fillRect(0,0,64,64);
    const shadowTexture=new THREE.CanvasTexture(shadowCanvas);textures.push(shadowTexture);const shadowMat=new THREE.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false});mats.push(shadowMat);const shadowGeo=new THREE.PlaneGeometry(2.5,1.7);geometries.push(shadowGeo);const shadow=new THREE.Mesh(shadowGeo,shadowMat);shadow.rotation.x=-Math.PI/2;shadow.position.y=-1.543;scene.add(shadow);

    let localAngle=-.28,lastPropAngle=controls.current.angle,lastColor=color,drag=false,lastX=0,lastY=0,pitch=-.025,visible=true,previousTime=0,phase=0,slowFrames=0;
    const render=()=>{ if(!disposed) renderer.render(scene,camera); };
    const frame=(time:number)=>{
      const delta=previousTime?Math.min((time-previousTime)/1000,.06):0;previousTime=time;
      if(!controls.current.paused&&!drag)phase+=delta;
      jersey.rotation.y=localAngle+(!controls.current.paused?Math.sin(phase*.45)*.24:0);
      jersey.rotation.x=pitch;jersey.rotation.z=-.035;
      jersey.position.y=!controls.current.paused?Math.sin(phase*.8)*.035:0;
      render();
      if(delta>.045&&++slowFrames>90){renderer.setPixelRatio(1);slowFrames=-10000;}
    };
    const syncLoop=()=>{previousTime=0;renderer.setAnimationLoop(visible&&!document.hidden&&!controls.current.paused?frame:null);frame(0);};
    update.current=()=>{
      if(lastColor!==controls.current.color){lastColor=controls.current.color;drawTexture(frontCanvas,false);drawTexture(backCanvas,true);frontTexture.needsUpdate=backTexture.needsUpdate=true;trimMaterial.color.set(lastColor);ringMat.color.set(lastColor);}
      localAngle+=controls.current.angle-lastPropAngle;lastPropAngle=controls.current.angle;syncLoop();
    };
    const resize=()=>{const {width,height}=container.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height,false);camera.aspect=width/height;camera.position.z=width<320?5.5:5.1;camera.updateProjectionMatrix();render();};
    const resizeObserver=new ResizeObserver(resize);resizeObserver.observe(container);resize();
    const intersection=new IntersectionObserver(([entry])=>{visible=entry.isIntersecting;syncLoop();},{threshold:.01});intersection.observe(container);
    const visibility=()=>syncLoop();document.addEventListener("visibilitychange",visibility);
    const down=(e:PointerEvent)=>{drag=true;lastX=e.clientX;lastY=e.clientY;container.setPointerCapture(e.pointerId);};
    const move=(e:PointerEvent)=>{if(!drag)return;localAngle+=(e.clientX-lastX)*.009;if(e.pointerType==="mouse")pitch=THREE.MathUtils.clamp(pitch+(e.clientY-lastY)*.002,-.25,.25);lastX=e.clientX;lastY=e.clientY;frame(0);};
    const up=()=>{drag=false;};
    const keyboard=(e:KeyboardEvent)=>{if(e.key==="ArrowLeft"||e.key==="ArrowRight"){e.preventDefault();localAngle+=e.key==="ArrowLeft"?-.25:.25;frame(0);}if(e.key==="Home"){e.preventDefault();localAngle=-.28;pitch=-.025;frame(0);}};
    const contextLost=(e:Event)=>{e.preventDefault();controls.current.onError();};
    container.addEventListener("pointerdown",down);container.addEventListener("pointermove",move);container.addEventListener("pointerup",up);container.addEventListener("pointercancel",up);container.addEventListener("lostpointercapture",up);container.addEventListener("keydown",keyboard);renderer.domElement.addEventListener("webglcontextlost",contextLost);
    document.fonts.ready.then(()=>{if(!disposed){drawTexture(frontCanvas,false);drawTexture(backCanvas,true);frontTexture.needsUpdate=backTexture.needsUpdate=true;render();}});
    syncLoop();
    return ()=>{disposed=true;update.current=null;renderer.setAnimationLoop(null);resizeObserver.disconnect();intersection.disconnect();document.removeEventListener("visibilitychange",visibility);container.removeEventListener("pointerdown",down);container.removeEventListener("pointermove",move);container.removeEventListener("pointerup",up);container.removeEventListener("pointercancel",up);container.removeEventListener("lostpointercapture",up);container.removeEventListener("keydown",keyboard);renderer.domElement.removeEventListener("webglcontextlost",contextLost);geometries.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();};
  }, []);
  return <div ref={host} className="uniform-canvas" tabIndex={0} role="img" aria-label="Interactive 3D basketball concept jersey. Drag horizontally or use left and right arrow keys to rotate. Press Home to reset."/>;
}
