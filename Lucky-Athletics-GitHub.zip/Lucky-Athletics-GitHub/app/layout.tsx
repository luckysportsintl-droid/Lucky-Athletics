import type { Metadata } from "next";
import "./globals.css";
import "@fontsource/barlow-condensed/700.css";
import "@fontsource/barlow-condensed/800.css";
import "@fontsource/manrope/400.css";
import "@fontsource/manrope/500.css";
import "@fontsource/manrope/600.css";
import "@fontsource/manrope/700.css";

export const metadata: Metadata = {
  title: "Lucky Athletics | Custom Uniforms. Every Sport. Your Identity.",
  description: "Custom sportswear for every sport. Unlimited designs and free mockups. We can match your current design. Your name, logo and sponsors, with unlimited customization. Call Lucky Athletics at +1 770 523 6138.",
  openGraph: { title: "Lucky Athletics — Built for Your Team", description: "Unlimited designs. Free mockups. Your name, logo and sponsors. Custom uniforms for every sport.", type: "website" },
  icons: {
    icon: "/images/lucky-logo.png",
    shortcut: "/images/lucky-logo.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
