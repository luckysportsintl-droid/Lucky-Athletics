const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const ts=require('typescript');
const {createCanvas,loadImage}=require('@napi-rs/canvas');
for(const ext of ['.ts','.tsx'])require.extensions[ext]=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,f);
const {categories,designs,colorways}=require('../lib/catalog.ts');
const {prepareTemplate,renderMockup}=require('../lib/mockup-renderer.ts');
const root=path.resolve(__dirname,'..');
(async()=>{
 let files=0;
 const ids=new Set();for(const design of designs){assert(!ids.has(design.id),'Unique design ID');ids.add(design.id);}
 for(const category of categories){
  const hashes=new Set();
  for(const design of designs)for(const size of [320,640]){
   const name=path.join(root,`public/mockups/${category.id}/${String(design.id).padStart(2,'0')}-${size}.avif`);
   const data=fs.readFileSync(name);assert(data.length>1000,`Empty preview: ${name}`);
   if(size===320)hashes.add(crypto.createHash('sha256').update(data).digest('hex'));
   files++;
  }
  assert.equal(hashes.size,designs.length,`Repeated product previews in ${category.name}`);
 }
 const category=categories[0],template=prepareTemplate(await loadImage(path.join(root,'public/templates/basketball.webp')),category,createCanvas);
 const a=createCanvas(640,720),b=createCanvas(640,720);
 renderMockup(a,template,category,designs[0],createCanvas);
 renderMockup(b,template,category,{...designs[0],...colorways[1]},createCanvas);
 assert.notDeepEqual(a.encodeSync('png'),b.encodeSync('png'),'Color changes must update the product');
 const all=createCanvas(1440,1800),ctx=all.getContext('2d');ctx.fillStyle='#f2f2ed';ctx.fillRect(0,0,1440,1800);
 for(let i=0;i<categories.length;i++){
  const c=categories[i],d=designs[(i*5)%designs.length];const x=i%4*360,y=Math.floor(i/4)*300;
  const img=await loadImage(path.join(root,`public/mockups/${c.id}/${String(d.id).padStart(2,'0')}-640.avif`));
  ctx.drawImage(img,x+40,y,280,270);ctx.fillStyle='#171719';ctx.font='bold 15px sans-serif';ctx.textAlign='center';ctx.fillText(c.name+' / '+d.name,x+180,y+287);
 }
 fs.mkdirSync(path.join(root,'review'),{recursive:true});fs.writeFileSync(path.join(root,'review/all-categories.png'),all.encodeSync('png'));
 const colors=createCanvas(960,540),cc=colors.getContext('2d');cc.fillStyle='#efefea';cc.fillRect(0,0,960,540);cc.drawImage(a,0,0,480,540);cc.drawImage(b,480,0,480,540);fs.writeFileSync(path.join(root,'review/color-preview.png'),colors.encodeSync('png'));
 console.log(JSON.stringify({status:'passed',categories:categories.length,distinctDesignsPerCategory:designs.length,images:files,colorChangesProduct:true}));
})().catch(e=>{console.error(e);process.exitCode=1;});
