/* Render the actual React page and enforce the no-forms/contact contract. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const Module = require('node:module');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function(request, parent, ...rest) {
  if (request.startsWith('@/')) request = path.join(root, request.slice(2));
  return originalResolve.call(this, request, parent, ...rest);
};
for (const extension of ['.tsx', '.ts']) require.extensions[extension] = function(module, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  const result = ts.transpileModule(source, { compilerOptions: { jsx: ts.JsxEmit.ReactJSX, module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true } });
  module._compile(result.outputText, filename);
};
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');
const Page = require('../app/page.tsx').default;
const { contact } = require('../lib/content.ts');
const {categories,designs}=require('../lib/catalog.ts');
const html = renderToStaticMarkup(React.createElement(Page));
assert(!/<(?:form|input|textarea|select)\b/i.test(html), 'No forms or fields may render');
assert(html.includes('href="tel:+17705236138"'), 'Phone link is correct');
assert(html.includes('href="mailto:luckysportsintl@gmail.com"'), 'Email link is correct');
assert(html.includes('Sample testimonials'), 'Fictional reviews must be labeled');
assert(html.includes('id="uniform-lab"'), 'Uniform Lab renders');
assert.equal(categories.length,24);
assert(designs.length>0,'At least one design is required');
for (const category of categories) assert(html.includes(category.name.replaceAll('&','&amp;')), `Missing ${category.name}`);
for (const design of designs) assert(html.includes(design.name), `Missing ${design.name}`);
for (const file of ['app/page.tsx','components/catalog-experience.tsx','components/product-stage.tsx','components/design-grid-canvas.tsx']) assert(!/<(?:form|input|textarea|select)\b/i.test(fs.readFileSync(path.join(root,file),'utf8')), `Prohibited element in ${file}`);
for (const [,url] of html.matchAll(/src="(\/images\/[^"]+)"/g)) assert(fs.existsSync(path.join(root,'public',url)), `Missing ${url}`);
for (const [,anchor] of html.matchAll(/href="#([^"]+)"/g)) assert(html.includes(`id="${anchor}"`), `Broken anchor #${anchor}`);
assert(!/360(?:°|[- ]degree)?|24(?:<!-- -->|\s)*(?:custom )?designs|designs each|turn it around|Drag to rotate/i.test(html), 'Outdated design-limit or rotation copy');
for (const phrase of ['Unlimited designs','Free mockups','match your current design','Your name, logo &amp; sponsors','Unlimited customization']) assert(html.includes(phrase), `Missing service message: ${phrase}`);
const catalogSource=fs.readFileSync(path.join(root,'components/catalog-experience.tsx'),'utf8');
assert(!/ProductStage|DesignGridCanvas|setInterval|requestAnimationFrame|useMotion|Enable 3D/.test(catalogSource),'Animated product runtime must not be mounted');
assert(html.includes('/images/custom-uniforms-banner.png'),'Supplied opening banner must render');
assert(!/Pause collection|Play collection|Enable live|3D design library/.test(html),'Obsolete animation controls');
console.log(JSON.stringify({status:'passed',renderedBytes:Buffer.byteLength(html),categories:categories.length,designsPerCategory:designs.length,noForms:true,contactLinks:true,localImages:true,anchors:true,phone:contact.phone}));

// The finished-product library must never silently fall back to a swatch.
for (const category of categories) {
  assert(fs.existsSync(path.join(root,`public/templates/${category.id}.webp`)), `Missing template ${category.id}`);
  for (const design of designs) for (const size of [320,640]) {
    const asset=path.join(root,`public/mockups/${category.id}/${String(design.id).padStart(2,'0')}-${size}.avif`);
    assert(fs.existsSync(asset), `Missing product mockup: ${asset}. Run pnpm mockups.`);
  }
}
assert(!html.includes('fabric-pattern-swatch'),'Product gallery must not use detached pattern swatches');
assert(html.includes('srcSet='),'Responsive product images required');
