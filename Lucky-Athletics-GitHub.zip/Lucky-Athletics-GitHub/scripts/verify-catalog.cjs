const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Module=require('node:module');
const ts=require('typescript');
const root=path.resolve(__dirname,'..');
const original=Module._resolveFilename;
Module._resolveFilename=function(request,parent,...rest){if(request.startsWith('@/'))request=path.join(root,request.slice(2));return original.call(this,request,parent,...rest);};
for(const ext of ['.ts','.tsx'])require.extensions[ext]=function(module,filename){module._compile(ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText,filename);};
const {categories,designs,designCode}=require('../lib/catalog.ts');
assert.equal(categories.length,24);assert.equal(designs.length,24);
assert.equal(new Set(categories.map(c=>c.id)).size,24);
assert.equal(new Set(designs.map(d=>d.motif)).size,24,'Designs must have different graphic layouts');
const codes=categories.flatMap(c=>designs.map(d=>designCode(c,d)));
assert.equal(new Set(codes).size,576,'Every concept must have a unique contact code');
for(const c of categories){assert(fs.existsSync(path.join(root,`public/images/catalog-${c.sheet}.webp`)));assert(c.cell>=0&&c.cell<12);}
// Geometry-only smoke check: no WebGL or browser claims. Canvas calls are stubs.
const context=new Proxy({createLinearGradient:()=>({addColorStop(){}})}, {get:(target,key)=>key in target?target[key]:(()=>{})});
global.document={createElement:()=>({width:512,height:512,getContext:()=>context})};
const THREE=require('three');
const {createProduct}=require('../lib/product-mesh.ts');
let meshes=0,triangles=0;const fabricProfiles=new Set();
for(let i=0;i<categories.length;i++){
 const asset=createProduct(categories[i],designs[i],128);
 const bounds=new THREE.Box3().setFromObject(asset.group);const size=bounds.getSize(new THREE.Vector3());
 assert([size.x,size.y,size.z].every(n=>Number.isFinite(n)&&n>0),`${categories[i].name}: invalid bounds`);
 assert(Math.max(size.y,size.x*.92)<=2.751,`${categories[i].name}: out of framing bounds`);
 asset.group.traverse(object=>{if(!object.isMesh)return;meshes++;for(const material of [object.material].flat()) { assert(material.isMeshPhysicalMaterial,'All product surfaces must use fabric shading'); assert(material.normalMap?.isDataTexture&&material.roughnessMap?.isDataTexture,'Missing textile relief or roughness'); assert.equal(material.metalness,0,'Fabric must not look metallic'); assert(material.sheen>0,'Missing fiber sheen'); fabricProfiles.add(material.userData.fabricProfile); }const pos=object.geometry.attributes.position;assert([...pos.array].every(Number.isFinite),`${categories[i].name}: invalid vertex`);triangles+=(object.geometry.index?.count??pos.count)/3;});
 asset.dispose();
}
assert.equal(fabricProfiles.size,3,'Uniforms, fleece and bags need distinct fabric profiles');
for(const file of ['app/page.tsx','components/catalog-experience.tsx','components/product-stage.tsx','components/design-grid-canvas.tsx'])assert(!/<(?:form|input|textarea|select)\b/i.test(fs.readFileSync(path.join(root,file),'utf8')),`Forbidden field: ${file}`);
console.log(JSON.stringify({status:'passed',categories:24,layouts:24,uniqueConceptCodes:576,categoryMeshes:meshes,triangles:Math.round(triangles),finiteGeometry:true,fabricProfiles:[...fabricProfiles],noFields:true}));
