/* Render the actual React page and enforce the no-forms/contact contract. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const Module = require('node:module');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function(request, parent, ...rest) {
  if (request.startsWith('@/')) request = path.join(root, request.slice(2));
  return originalResolve.call(this, request, parent, ...rest);
};
for (const extension of ['.tsx', '.ts']) require.extensions[extension] = function(module, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  const result = ts.transpileModule(source, { compilerOptions: { jsx: ts.JsxEmit.ReactJSX, module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true } });
  module._compile(result.outputText, filename);
};
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');
const Page = require('../app/page.tsx').default;
const markup = require('react-dom/server').renderToString(React.createElement(Page));
const template = fs.readFileSync(path.join(root, 'index.template.html'), 'utf8');
fs.writeFileSync(path.join(root, 'index.html'), template.replace('<!--APP_HTML-->', markup));
console.log('Prerendered Lucky Athletics for static hosting.');
