// DOM integration tests; not a substitute for real-browser visual/device QA.
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),ts=require('typescript');
const {JSDOM}=require('jsdom');
const dom=new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>',{url:'http://localhost/',pretendToBeVisual:true});
for(const key of ['window','document','navigator','HTMLElement','HTMLButtonElement','HTMLInputElement','Node','NodeFilter','Element','Event','MouseEvent','CustomEvent','MutationObserver','getComputedStyle','DocumentFragment','HTMLCanvasElement'])Object.defineProperty(globalThis,key,{value:dom.window[key],configurable:true,writable:true});
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
globalThis.requestAnimationFrame=cb=>setTimeout(cb,0);globalThis.cancelAnimationFrame=clearTimeout;
HTMLElement.prototype.scrollIntoView=function(){};
const root=path.resolve(__dirname,'..'),originalResolve=Module._resolveFilename;
Module._resolveFilename=function(request,parent,...rest){if(request.startsWith('@/'))request=path.join(root,request.slice(2));return originalResolve.call(this,request,parent,...rest);};
for(const ext of ['.tsx','.ts'])require.extensions[ext]=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText,f);
const React=require('react'),{createRoot}=require('react-dom/client');
const Catalog=require('../components/catalog-experience.tsx').default;
const {categories,designs}=require('../lib/catalog.ts');
const click=async element=>{assert(element,'Control exists');await React.act(async()=>{element.dispatchEvent(new MouseEvent('click',{bubbles:true}));});};
(async()=>{
 const app=createRoot(document.getElementById('root'));await React.act(async()=>{app.render(React.createElement(Catalog));});
 assert.equal(document.querySelectorAll('.studio-category').length,24);
 for(const category of categories){
  await click(document.querySelector(`[aria-label="Explore ${category.name} designs"]`));
  const cards=[...document.querySelectorAll('.design-card')];assert.equal(cards.length,designs.length);
  assert(cards.every(c=>c.querySelector('img').getAttribute('src').includes(`/mockups/${category.id}/`)));
 }
 await click(document.querySelector('[aria-label="Explore Basketball designs"]'));
 await click(document.querySelector('.design-card'));
 assert(document.querySelector('[role="dialog"]'),'Modal opens');
 assert(document.querySelector('.studio-modal-product img').src.includes('/basketball/01-640.avif'));
 const dialog=document.querySelector('[role="dialog"]');
 await click([...dialog.querySelectorAll('button')].find(b=>b.textContent.includes('Previous design')));
 assert(document.querySelector('.studio-modal-product img').src.includes(`/${String(designs[designs.length-1].id).padStart(2,'0')}-640.avif`),'Previous wraps to last design');
 await click([...dialog.querySelectorAll('button')].find(b=>b.textContent.includes('Next design')));
 assert(document.querySelector('.studio-modal-product img').src.includes('/01-640.avif'),'Next wraps to first design');
 await click(document.querySelector('[aria-label="Royal blue"]'));
 assert.equal(document.querySelector('[aria-label="Royal blue"]').getAttribute('aria-pressed'),'true');
 const email=document.querySelector('.design-modal-copy a[href^="mailto:"]').href;
 assert(decodeURIComponent(email).includes('Royal blue'),'Enquiry includes selected colors');
 await click(document.querySelector('.original-color'));
 assert(!document.querySelector('.color-mockup'),'Original resets product preview');
 await click(document.querySelector('[data-slot="dialog-close"]'));
 assert(!document.querySelector('[role="dialog"]'),'Modal closes');
 await React.act(async()=>{await new Promise(resolve=>setTimeout(resolve,20));});
 assert(document.activeElement.classList.contains('design-card'),'Focus returns to design card');
 // Tabs use pointerdown and keyboard activation; test keyboard on their public role.
 const bagTab=[...document.querySelectorAll('[role="tab"]')].find(b=>b.textContent.startsWith('Bags'));
 await React.act(async()=>{bagTab.focus();bagTab.dispatchEvent(new dom.window.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));});
 assert.equal(document.querySelectorAll('.studio-category').length,4,'Bag filter');
 await React.act(async()=>{app.unmount();});dom.window.close();
 console.log(JSON.stringify({status:'passed',categorySwitches:24,designsPerCategory:designs.length,modal:true,previousNextWrap:true,enquiryColor:true,focusRestoration:true,bagFilter:true}));
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1;});
