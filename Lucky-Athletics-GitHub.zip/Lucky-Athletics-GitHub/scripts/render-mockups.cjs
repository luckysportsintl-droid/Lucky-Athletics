/* Offline studio render: no browser, WebGL, network or API keys required. */
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const {createCanvas,loadImage}=require('@napi-rs/canvas');
for(const ext of ['.ts','.tsx']) require.extensions[ext]=(module,filename)=>{
 const source=fs.readFileSync(filename,'utf8');
 const result=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}});
 module._compile(result.outputText,filename);
};
const {categories,designs}=require('../lib/catalog.ts');
const {prepareTemplate,renderMockup}=require('../lib/mockup-renderer.ts');
const root=path.resolve(__dirname,'..');
const factory=(w,h)=>createCanvas(w,h);
(async()=>{
 const sheets=await Promise.all([1,2].map(n=>loadImage(path.join(root,`public/templates/products-${n}.png`))));
 let bytes=0,count=0;
 for(const category of categories){
  const sheet=sheets[category.sheet-1];
  const tile=createCanvas(384,342),ctx=tile.getContext('2d');
  ctx.drawImage(sheet,(category.cell%4)*sheet.width/4,Math.floor(category.cell/4)*sheet.height/3,sheet.width/4,sheet.height/3,0,0,384,342);
  const templateFile=path.join(root,`public/templates/${category.id}.webp`);
  fs.writeFileSync(templateFile,tile.encodeSync('webp',95));
  const template=prepareTemplate(tile,category,factory);
  const folder=path.join(root,'public/mockups',category.id);fs.mkdirSync(folder,{recursive:true});
  for(const design of designs){
   const artwork=design.texture?await loadImage(path.join(root,'public',design.texture)):undefined;
   const large=createCanvas(640,720);renderMockup(large,template,category,design,factory,artwork);
   for(const size of [320,640]){
    const canvas=size===640?large:createCanvas(320,360);
    if(size===320)canvas.getContext('2d').drawImage(large,0,0,320,360);
    const buffer=canvas.encodeSync('avif',{quality:40,alphaQuality:85,speed:8,threads:1});
    fs.writeFileSync(path.join(folder,`${String(design.id).padStart(2,'0')}-${size}.avif`),buffer);bytes+=buffer.length;count++;
   }
  }
  console.log(`Rendered ${category.name}: ${designs.length} finished-product designs`);
 }
 console.log(`${count} responsive AVIF images, ${(bytes/1024/1024).toFixed(1)} MiB total. Only visible categories load in the browser.`);
})().catch(e=>{console.error(e);process.exitCode=1;});
