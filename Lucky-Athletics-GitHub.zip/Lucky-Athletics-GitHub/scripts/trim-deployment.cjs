// Source atlases are build inputs only. Color previews use category WebP tiles.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
for(const n of [1,2])fs.rmSync(path.join(root,`dist/templates/products-${n}.png`),{force:true});
