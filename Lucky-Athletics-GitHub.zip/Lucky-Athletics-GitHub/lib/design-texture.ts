import type { Design } from './catalog';
/** Twenty-four actual graphic layouts, shared across category-specific geometry. */
export function paintDesign(canvas:HTMLCanvasElement,design:Design,branding:'jersey'|'bag'|'plain'='jersey',back=false){
 const c=canvas.getContext('2d')!;const size=canvas.width;c.save();c.scale(size/512,size/512);
 c.fillStyle=design.primary;c.fillRect(0,0,512,512);
 const polygon=(points:number[][],color=design.accent)=>{c.fillStyle=color;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.fill();};
 const band=(y:number,w:number,rotation:number,color=design.accent)=>{c.save();c.translate(256,y);c.rotate(rotation);c.fillStyle=color;c.fillRect(-500,-w/2,1000,w);c.restore();};
 const stripe=(x:number,w:number,color=design.accent)=>{c.fillStyle=color;c.fillRect(x,0,w,512);};
 switch(design.motif){
 case 'chevron':polygon([[0,90],[256,220],[512,90],[512,168],[256,290],[0,168]]);polygon([[0,76],[256,203],[512,76],[512,87],[256,214],[0,87]],design.trim);break;
 case 'diagonal':band(180,140,-.6);band(270,12,-.6,design.trim);break;
 case 'stripes':for(let x=30;x<512;x+=118){stripe(x,50);stripe(x+57,5,design.trim);}break;
 case 'gradient':{const g=c.createLinearGradient(0,0,512,512);g.addColorStop(0,design.primary);g.addColorStop(1,design.accent);c.fillStyle=g;c.fillRect(0,0,512,512);for(let i=0;i<9;i++)band(380+i*23,2,-.55,design.trim);break;}
 case 'split':stripe(256,256);stripe(247,8,design.trim);break;
 case 'curves':for(const sign of [-1,1]){c.save();c.translate(sign<0?0:512,0);c.scale(-sign,1);c.fillStyle=design.accent;c.beginPath();c.moveTo(0,0);c.bezierCurveTo(240,210,-80,220,135,512);c.lineTo(0,512);c.fill();c.restore();}break;
 case 'pinstripe':for(let x=0;x<512;x+=32)stripe(x,3,design.trim);stripe(0,35);stripe(477,35);break;
 case 'zigzag':for(let y=25;y<512;y+=100)polygon([[0,y],[128,y+65],[256,y],[384,y+65],[512,y],[512,y+35],[384,y+100],[256,y+35],[128,y+100],[0,y+35]]);break;
 case 'triangles':for(let y=0;y<512;y+=128)for(let x=0;x<512;x+=128)polygon([[x,y],[x+128,y+128],[x,y+128]],(x+y)%256?design.accent:design.primary);band(370,12,-.5,design.trim);break;
 case 'hoops':for(let y=35;y<512;y+=105){band(y,58,0);band(y+37,6,0,design.trim);}break;
 case 'solid':stripe(0,36);stripe(476,36);band(455,12,0,design.trim);break;
 case 'camo':for(let i=0;i<50;i++){const x=(i*137)%530-20,y=(i*97)%530-20;polygon([[x,y],[x+67,y-13],[x+89,y+25],[x+27,y+48],[x-14,y+21]],i%3?design.accent:design.trim);}c.fillStyle=design.primary+'a0';c.fillRect(0,0,512,512);break;
 case 'bolt':polygon([[350,0],[185,230],[286,205],[110,512],[375,206],[272,231],[451,0]]);polygon([[360,0],[202,217],[218,217],[376,0]],design.trim);break;
 case 'shards':polygon([[0,0],[512,0],[140,245]]);polygon([[512,140],[512,512],[310,315]],design.trim);polygon([[0,305],[320,512],[0,512]]);break;
 case 'waves':for(let y=0;y<600;y+=65){c.strokeStyle=design.accent;c.lineWidth=27;c.beginPath();c.moveTo(0,y);c.bezierCurveTo(140,y-95,330,y+95,512,y);c.stroke();}break;
 case 'grid':c.strokeStyle=design.accent;c.lineWidth=3;for(let x=0;x<512;x+=48){c.beginPath();c.moveTo(x,0);c.lineTo(x,512);c.stroke();c.beginPath();c.moveTo(0,x);c.lineTo(512,x);c.stroke();}band(375,70,-.55);break;
 case 'slashes':for(let i=0;i<3;i++)band(90+i*108,47,-.64);break;
 case 'yoke':polygon([[0,0],[512,0],[512,140],[390,190],[256,152],[122,190],[0,140]]);band(435,12,0,design.trim);break;
 case 'fade':{const g=c.createLinearGradient(0,120,0,500);g.addColorStop(0,design.primary);g.addColorStop(1,design.accent);c.fillStyle=g;c.fillRect(0,0,512,512);for(let x=0;x<512;x+=20){c.fillStyle=design.primary;c.fillRect(x,360+Math.sin(x)*45,7,180);}break;}
 case 'sash':band(250,113,.68,design.trim);band(250,80,.68);break;
 case 'dots':for(let y=0;y<512;y+=22)for(let x=0;x<512;x+=22){c.fillStyle=design.accent;c.beginPath();c.arc(x+(y%44?11:0),y,2+y/65,0,Math.PI*2);c.fill();}break;
 case 'angles':polygon([[0,0],[155,0],[350,512],[0,512]]);polygon([[390,0],[512,0],[512,512],[430,512],[235,0]],design.trim);break;
 case 'border':stripe(20,34);stripe(458,34);band(468,32,0);stripe(62,7,design.trim);stripe(443,7,design.trim);break;
 case 'two-tone':band(120,240,0);band(245,13,0,design.trim);break;
 }
 if(branding!=='plain'){
  c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  c.strokeStyle=design.primary;c.lineWidth=8;c.fillStyle=design.trim;
  c.font="800 44px 'Barlow Condensed',Impact,sans-serif";
  c.strokeText(back?'ATHLETICS':'LUCKY',256,branding==='bag'?210:155);c.fillText(back?'ATHLETICS':'LUCKY',256,branding==='bag'?210:155);
  if(branding==='jersey'){c.font="800 190px 'Barlow Condensed',Impact,sans-serif";c.lineWidth=9;c.strokeText('07',256,294);c.fillText('07',256,294);}else{c.font="700 16px Manrope,Arial,sans-serif";c.fillText('A T H L E T I C S',256,248);}
 }
 // Fine yarn relief and surface roughness are supplied by the shared fabric material.
 c.restore();
}
