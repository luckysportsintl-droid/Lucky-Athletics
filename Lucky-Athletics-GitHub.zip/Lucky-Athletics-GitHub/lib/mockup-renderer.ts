import { paintDesign } from './design-texture';
import type { Category, Design } from './catalog';

export type CanvasFactory = (width: number, height: number) => HTMLCanvasElement;
export type PreparedTemplate = {
  width: number; height: number; pixels: Uint8ClampedArray;
  bounds: { left: number; top: number; width: number; height: number }[];
};
// UV regions are normalized to each atlas cell. Garment pieces receive the same
// design separately so a chest graphic is not stretched across a whole kit.
const panels: Record<string, number[][]> = {
  basketball: [[0,0,1,.55],[0,.55,1,.45]],
  cheer: [[0,0,1,.46],[0,.46,1,.54]],
  football: [[0,0,1,.50],[0,.50,1,.50]],
  soccer: [[0,0,1,.68],[0,.68,1,.32]],
  lacrosse: [[0,0,1,.61],[0,.61,1,.39]],
  track: [[0,0,1,.63],[0,.63,1,.37]],
  baseball: [[0,0,.63,.53],[0,.53,.63,.47],[.63,0,.37,1]],
  softball: [[0,0,.65,.55],[0,.55,.65,.45],[.65,0,.35,1]],
  volleyball: [[0,0,1,.72],[0,.72,1,.28]],
  rugby: [[0,0,1,.65],[0,.65,1,.35]],
  cricket: [[0,0,.61,1],[.61,0,.39,1]],
  tennis: [[0,0,1,.65],[0,.65,1,.35]],
  cycling: [[0,0,.62,.64],[0,.64,.62,.36],[.62,0,.38,1]],
  tracksuit: [[0,0,.62,1],[.62,0,.38,1]],
  training: [[0,0,1,.60],[0,.60,1,.40]],
};
const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

export function prepareTemplate(image: CanvasImageSource, category: Category, factory: CanvasFactory): PreparedTemplate {
  const width=384, height=342, c=factory(width,height), ctx=c.getContext('2d')!;
  ctx.drawImage(image,0,0,width,height);
  const pixels=ctx.getImageData(0,0,width,height).data;
  // Remove near-transparent generator residue while preserving antialiased edges.
  for(let i=3;i<pixels.length;i+=4) pixels[i]=pixels[i]<32?0:Math.min(255,Math.round((pixels[i]-32)*255/220));
  // Discard tiny disconnected flecks (or a neighboring atlas-cell fragment).
  const seen=new Uint8Array(width*height), queue=new Int32Array(width*height);
  for(let seed=0;seed<seen.length;seed++) {
    if(seen[seed]||pixels[seed*4+3]===0)continue;
    let head=0,tail=1;queue[0]=seed;seen[seed]=1;
    while(head<tail){
      const p=queue[head++],px=p%width,py=Math.floor(p/width);
      for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
        const x=px+dx,y=py+dy;if(x<0||x>=width||y<0||y>=height)continue;
        const next=y*width+x;if(!seen[next]&&pixels[next*4+3]>0){seen[next]=1;queue[tail++]=next;}
      }
    }
    if(tail<width*height*.003)for(let k=0;k<tail;k++)pixels[queue[k]*4+3]=0;
  }
  const regions=panels[category.id] ?? [[0,0,1,1]];
  const bounds=regions.map(([x,y,w,h])=>{
    let left=width, right=0, top=height, bottom=0;
    for(let py=Math.floor(y*height);py<Math.min(height,Math.ceil((y+h)*height));py++) {
      for(let px=Math.floor(x*width);px<Math.min(width,Math.ceil((x+w)*width));px++) {
        if(pixels[(py*width+px)*4+3]>100){left=Math.min(left,px);right=Math.max(right,px);top=Math.min(top,py);bottom=Math.max(bottom,py);}
      }
    }
    return {left,top,width:Math.max(1,right-left+1),height:Math.max(1,bottom-top+1)};
  });
  return {width,height,pixels,bounds};
}

/** Shared deterministic renderer: Node build thumbnails and browser color previews.
 * True template alpha clips the print; luminance restores folds and fabric relief.
 * Small UV displacement bends graphics with the photographed surface.
 */
export function renderMockup(output: HTMLCanvasElement, template: PreparedTemplate, category: Category, design: Design, factory: CanvasFactory, artwork?: CanvasImageSource) {
  const {width,height,pixels,bounds}=template;
  const texture=factory(512,512), tc=texture.getContext('2d')!;
  paintDesign(texture,design,'plain');
  if(artwork) tc.drawImage(artwork,0,0,512,512);
  const print=tc.getImageData(0,0,512,512).data;
  const product=factory(width,height), pc=product.getContext('2d')!, mapped=pc.createImageData(width,height);
  const regions=panels[category.id] ?? [[0,0,1,1]];
  const luminance=(x:number,y:number)=>pixels[(clamp(y,0,height-1)*width+clamp(x,0,width-1))*4]/255;
  for(let y=0;y<height;y++) for(let x=0;x<width;x++) {
    const i=(y*width+x)*4, alpha=pixels[i+3]; if(alpha===0)continue;
    const panel=Math.max(0,regions.findIndex(([rx,ry,rw,rh])=>x>=rx*width&&x<(rx+rw)*width&&y>=ry*height&&y<(ry+rh)*height));
    const b=bounds[panel];
    const shade=(pixels[i]+pixels[i+1]+pixels[i+2])/765;
    // Retain dark hardware: zip teeth, bag straps, buckles and buttons.
    const hardware=shade<.20;
    let u=(x-b.left)/b.width, v=(y-b.top)/b.height;
    u+=(luminance(x+2,y)-luminance(x-2,y))*.036;
    v+=(luminance(x,y+2)-luminance(x,y-2))*.022;
    const tx=clamp(u*511,0,511),ty=clamp(v*511,0,511), x0=Math.floor(tx),y0=Math.floor(ty);
    const x1=Math.min(511,x0+1),y1=Math.min(511,y0+1),fx=tx-x0,fy=ty-y0;
    // Bilinear sampling prevents thin stripes from breaking at fabric folds.
    const sample=(channel:number)=>{
      const a=print[(y0*512+x0)*4+channel]*(1-fx)+print[(y0*512+x1)*4+channel]*fx;
      const b=print[(y1*512+x0)*4+channel]*(1-fx)+print[(y1*512+x1)*4+channel]*fx;
      return a*(1-fy)+b*fy;
    };
    const relief=clamp(Math.pow(shade/.83,1.4),.18,1.17);
    const specular=Math.max(0,shade-.73)*48;
    for(let k=0;k<3;k++) mapped.data[i+k]=hardware?pixels[i+k]:clamp(sample(k)*relief+specular,0,255);
    mapped.data[i+3]=alpha;
  }
  pc.putImageData(mapped,0,0);
  const ctx=output.getContext('2d')!;
  ctx.clearRect(0,0,output.width,output.height);
  // Transparent outputs work on both warm-white gallery and dark category cards.
  const scale=Math.min(output.width*.92/width,output.height*.88/height);
  const dw=width*scale,dh=height*scale,left=(output.width-dw)/2,top=(output.height-dh)/2;
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
  ctx.drawImage(product,left,top,dw,dh);
}
