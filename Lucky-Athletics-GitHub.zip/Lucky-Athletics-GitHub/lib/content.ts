export const contact = { phone: "+1 770 523 6138", tel: "tel:+17705236138", email: "luckysportsintl@gmail.com", emailLink: "mailto:luckysportsintl@gmail.com" };
export const emailFor = (subject: string) => `${contact.emailLink}?subject=${encodeURIComponent(`Lucky Athletics — ${subject}`)}`;
export const sports = [
  {name:"Football",description:"A complete identity for Friday nights, weekend leagues, and every down in between.",kit:["Game jerseys","Football pants","Practice gear","Flag & 7-on-7 kits"]},
  {name:"Basketball",description:"From the opening tip to the final buzzer, bring your team’s identity to the court.",kit:["Game jerseys","Basketball shorts","Reversible options","Shooting shirts"]},
  {name:"Baseball",description:"Classic diamond details with a look that belongs to your ball club.",kit:["Button-front jerseys","Pullover jerseys","Baseball pants","Team warm-ups"]},
  {name:"Soccer",description:"One club. One look. Create a complete kit for every match and training session.",kit:["Match jerseys","Soccer shorts","Goalkeeper kits","Training tops"]},
  {name:"Softball",description:"A unified look for your dugout, designed around your team’s colors and personality.",kit:["Game jerseys","Softball pants","Training shirts","Team warm-ups"]},
  {name:"Volleyball",description:"A confident team identity for every serve, set, and match point.",kit:["Short-sleeve jerseys","Long-sleeve jerseys","Volleyball shorts","Warm-up tops"]},
  {name:"Hockey",description:"Take your team’s look from the locker room to the ice.",kit:["Hockey jerseys","Practice jerseys","Hockey socks","Off-ice apparel"]},
  {name:"Lacrosse",description:"Custom teamwear for the pace, pride, and personality of your program.",kit:["Game jerseys","Lacrosse shorts","Pinnies","Training apparel"]},
  {name:"Wrestling",description:"Represent your program with a distinct look for every match.",kit:["Wrestling singlets","Two-piece kits","Warm-up suits","Team shirts"]},
  {name:"Track & Field",description:"Your team colors, from the starting blocks to the finish line.",kit:["Race singlets","Running shorts","Compression options","Track suits"]},
  {name:"Rugby",description:"A team identity made for the club, the pitch, and the full eighty minutes.",kit:["Rugby jerseys","Rugby shorts","Training tops","Club apparel"]},
  {name:"Cricket",description:"Build a complete club look for match days, training, and touring.",kit:["Match shirts","Cricket trousers","Training kits","Club polos"]},
  {name:"Cheer & Dance",description:"Coordinated teamwear that brings your squad’s personality to every performance.",kit:["Performance tops","Skirts & shorts","Practice wear","Team warm-ups"]},
  {name:"Tennis & Pickleball",description:"A coordinated court identity for clubs, school teams, and doubles partners.",kit:["Performance tops","Court shorts","Skorts","Club polos"]},
  {name:"Cycling",description:"Represent your club across every mile with a coordinated custom kit.",kit:["Cycling jerseys","Cycling shorts","Club training tops","Off-bike apparel"]},
  {name:"Esports",description:"A recognizable identity for your squad, on stage and online.",kit:["Team jerseys","Player shirts","Hoodies","Team jackets"]},
  {name:"Training & Teamwear",description:"Keep your team identity strong beyond game day.",kit:["Training tees","Team hoodies","Track suits","Staff polos"]},
];
// PLACEHOLDER REVIEWS. Replace with permission-cleared real reviews.
// Keep the sample label in app/page.tsx until every displayed review is verified.
export const testimonials = [
  {name:"Marcus T.",initials:"MT",role:"Youth football coach",sport:"FOOTBALL",quote:"The players couldn’t wait to put them on. Our colors, our name, and a look that finally felt like our team."},
  {name:"Danielle R.",initials:"DR",role:"Club basketball director",sport:"BASKETBALL",quote:"Being able to talk through the details with a real person made the whole process feel easy. The team loved the result."},
  {name:"Chris M.",initials:"CM",role:"Travel baseball coach",sport:"BASEBALL",quote:"From the first design conversation to the final look, every detail felt personal. We showed up looking like one team."},
];
export const faqs = [
  {question:"Can we use our own logo, colors, and design?",answer:"Absolutely. Email your logo, team colors, and any references you have in mind. We’ll talk through the options for your sport and work with you on a design. You’ll review the final artwork before confirming production."},
  {question:"Do you offer youth and adult sizes?",answer:"We work with youth and adult teams. Available size ranges and cuts depend on the uniform style, so contact us for the specific sizing information for your sport before collecting your roster’s sizes."},
  {question:"What is the minimum order and how much does it cost?",answer:"Minimums and pricing depend on the sport, garment, design, and quantity. Call or email us with your team size and what you need, and we’ll confirm the options and a quote before you commit."},
  {question:"How far ahead should we order?",answer:"Contact us as early as you can and share your first game or event date. Production and delivery timing vary by order. We’ll confirm the schedule with you before you approve your order, including whether your deadline can be met."},
  {question:"Can we reorder or add players later?",answer:"Get in touch with your original order details and the items you need. We’ll check matching options, current availability, minimum quantities, and lead times for your reorder."},
];
