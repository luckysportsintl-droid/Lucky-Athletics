import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import type { Category, Design, ProductKind } from './catalog';
import {paintDesign} from './design-texture';
import {createFabric} from './fabric-material';

export type ProductAsset={group:THREE.Group;dispose:()=>void};


export function createProduct(category:Category,design:Design,resolution=512):ProductAsset{
 const fabric=createFabric(category);
 const group=new THREE.Group();const geometries:THREE.BufferGeometry[]=[];const materials:THREE.Material[]=[];const textures:THREE.Texture[]=[];
 const material=(branding:'jersey'|'bag'|'plain'='plain',back=false)=>{const canvas=document.createElement('canvas');canvas.width=canvas.height=resolution;paintDesign(canvas,design,branding,back);const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=2;textures.push(texture);const m=fabric.material({map:texture});materials.push(m);return m;};
 const plain=material();const front=material(category.group==='Bags'?'bag':'jersey');const back=material(category.group==='Bags'?'bag':'jersey',true);
 const solid=(color:string)=>{const m=fabric.material({color});materials.push(m);return m;};
 const accent=solid(design.accent),trim=solid(design.trim),dark=solid('#191b20');
 const mesh=(geo:THREE.BufferGeometry,mat:THREE.Material|THREE.Material[],pos=[0,0,0],parent:THREE.Group=group)=>{geometries.push(geo);const m=new THREE.Mesh(geo,mat);m.position.set(pos[0],pos[1],pos[2]);parent.add(m);return m;};
 const line=(pts:number[][],mat:THREE.Material=trim,r=.016,parent:THREE.Group=group)=>mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p=>new THREE.Vector3(...p as [number,number,number]))),Math.max(18,pts.length*5),r,5,false),mat,[0,0,0],parent);
 const box=(w:number,h:number,d:number,pos:number[],mat:THREE.Material|THREE.Material[]=plain,r=.06)=>{
  const geometry=new RoundedBoxGeometry(w,h,d,5,r);const positions=geometry.attributes.position;
  for(let i=0;i<positions.count;i++){const x=positions.getX(i),y=positions.getY(i),z=positions.getZ(i);const edge=Math.max(0,1-(2*x/w)**2)*Math.max(0,1-(2*y/h)**2);const fold=(Math.sin(x*21+y*8)*.012+Math.sin(y*17-x*5)*.008)*edge;positions.setZ(i,z+Math.sign(z)*fold);}
  geometry.computeVertexNormals();return mesh(geometry,mat,pos);
 };
 const tube=(a:number[],b:number[],ra:number,rb:number,mat:THREE.Material=plain,parent:THREE.Group=group)=>{const v1=new THREE.Vector3(...a as [number,number,number]),v2=new THREE.Vector3(...b as [number,number,number]);const geo=new THREE.CylinderGeometry(ra,rb,v1.distanceTo(v2),28,18,true);
 const vertices=geo.attributes.position,uv=geo.attributes.uv;
 for(let i=0;i<vertices.count;i++){const v=uv.getY(i),u=uv.getX(i),envelope=Math.sin(Math.PI*v);const ripple=envelope*(.035*Math.sin(u*Math.PI*12+v*2)+.018*Math.sin(v*18+u*8));vertices.setX(i,vertices.getX(i)*(1+ripple));vertices.setZ(i,vertices.getZ(i)*(1+ripple));}geo.computeVertexNormals();const m=mesh(geo,mat,[0,0,0],parent);m.position.copy(v1.clone().add(v2).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),v1.sub(v2).normalize());return m;};
 const ellipse=(rx:number,rz:number,y:number,mat:THREE.Material=trim,r=.012,parent:THREE.Group=group)=>line(Array.from({length:49},(_,i)=>[Math.sin(i/48*Math.PI*2)*rx,y,Math.cos(i/48*Math.PI*2)*rz]),mat,r,parent);
 function torso(kind:'tank'|'shirt'|'long',scale:number,y:number,width=1){
  const clothing=new THREE.Group();clothing.scale.setScalar(scale);clothing.scale.x*=width;clothing.position.y=y;group.add(clothing);
  const surface=(u:number,v:number,rear=false)=>{const a=Math.abs(u);const top=kind==='tank'?(a<.36?.72+.48*(a/.36)**2:a<.69?1.2-.06*(a-.36)/.33:1.14-.82*((a-.69)/.31)**.65):1.12-.25*Math.exp(-u*u*24);const py=-1.0+(top+1)*v;const w=.72+.07*Math.sin(v*Math.PI);const envelope=Math.max(0,1-u*u);
   const drape=.024*Math.sin(u*23+v*3)*(1-v)**.7;
   const tension=.027*Math.sin(v*23-a*9)*Math.exp(-(((v-.68)/.27)**2))*a;
   const hem=.018*Math.sin(u*35+v*4)*Math.exp(-v*9);
   const z=(.29*Math.sqrt(envelope)+(drape+tension+hem)*envelope)*(rear?-1:1);
   return new THREE.Vector3(u*w,py+.009*Math.cos(u*19)*(1-v)**5,z);};
  for(const rear of [false,true]){const p:number[]=[],uv:number[]=[],idx:number[]=[];const n=resolution>=384?56:36;for(let j=0;j<=n;j++)for(let i=0;i<=n;i++){const q=surface(i/n*2-1,j/n,rear);p.push(q.x,q.y,q.z);uv.push(rear?1-i/n:i/n,j/n);}for(let j=0;j<n;j++)for(let i=0;i<n;i++){const a=j*(n+1)+i,b=a+1,c=a+n+1,d=c+1;idx.push(...(rear?[a,c,b,b,c,d]:[a,b,c,b,d,c]));}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();mesh(g,rear?back:front,[0,0,0],clothing);const points=Array.from({length:33},(_,i)=>surface(i/16-1,1,rear).toArray());line(points,accent,.017,clothing);}
  if(kind==='tank'){
   for(const s of [-1,1]){const a=surface(s*.5,1);tube([a.x,a.y,a.z],[a.x,a.y,-a.z],.11,.11,accent,clothing);}
  }else{
   for(const s of [-1,1]){
    tube([s*.67,.83,0],[s*(kind==='long'?1.12:1.1),kind==='long'?-.63:.23,0],.30,kind==='long'?.17:.25,plain,clothing);
    tube([s*(kind==='long'?1.12:1.1),kind==='long'?-.64:.22,0],[s*(kind==='long'?1.125:1.115),kind==='long'?-.72:.15,0],kind==='long'?.175:.255,kind==='long'?.175:.255,accent,clothing);
   }
   ellipse(.255,.25,.91,accent,.025,clothing);
   // Sewn shoulder bridges close the top without filling the collar opening.
   for(const s of [-1,1]){const g=new THREE.PlaneGeometry(.46,.44,4,4);const m=mesh(g,plain,[s*.49,1.08,0],clothing);m.rotation.x=-Math.PI/2;}
  }
  for(const rear of [false,true])for(const v of [.018,.033])line(Array.from({length:45},(_,i)=>{const p=surface(i/22-1,v,rear);p.z+=(rear?-1:1)*.003;return p.toArray();}),plain,.003,clothing);
  ellipse(.73,.28,-.985,accent,.014,clothing);return clothing;
 }
 function bottoms(long=false,short=false){const length=long?1.45:short?.42:.70;const waist=long?.16:-.16;box(1.09,.20,.44,[0,waist,0],accent,.04);for(const s of [-1,1]){const leg=tube([s*.27,waist-.06,0],[s*.31,waist-.06-length,0],.315,long?.23:.29,plain);leg.scale.z=.76;const cuff=tube([s*.31,waist-.06-length+.03,0],[s*.31,waist-.06-length-.025,0],long?.233:.294,long?.233:.294,accent);cuff.scale.z=.76;}}
 function skirt(){const pos:number[]=[],uv:number[]=[],idx:number[]=[];const rows=12,cols=64;for(let j=0;j<=rows;j++)for(let i=0;i<=cols;i++){const t=i/cols*Math.PI*2,v=j/rows,r=.5+v*.33+.025*Math.cos(t*16);pos.push(Math.sin(t)*r,-.12-v*.80,Math.cos(t)*r*.58);uv.push(i/cols,v);}for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){const a=j*(cols+1)+i;idx.push(a,a+cols+1,a+1,a+1,a+cols+1,a+cols+2);}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();mesh(g,plain);ellipse(.84,.48,-.91,trim,.025);ellipse(.51,.30,-.12,accent,.055);}
 function zip(parent:THREE.Group){line([[0,.86,.295],[0,.2,.31],[0,-.95,.295]],dark,.019,parent);line([[.02,.86,.299],[.02,.2,.315],[.02,-.95,.299]],trim,.006,parent);}
 const kind:ProductKind=category.id;
 if(category.group==='Bags'){
  if(kind==='backpack'){
   box(1.45,1.9,.62,[0,0,0],[plain,plain,dark,plain,front,back],.20);box(1.12,.70,.20,[0,-.36,.36],plain,.12);
   line([[-.5,.04,.48],[0,.08,.5],[.5,.04,.48]],trim,.014);line([[-.60,.55,.34],[-.49,.82,.34],[0,.9,.34],[.49,.82,.34],[.60,.55,.34]],trim,.012);
   line([[-.25,.91,0],[-.25,1.18,0],[.25,1.18,0],[.25,.91,0]],dark,.06);
   for(const s of [-1,1]){line([[s*.42,.75,-.30],[s*.63,.25,-.67],[s*.49,-.62,-.65],[s*.46,-.80,-.25]],dark,.085);box(.17,.20,.06,[s*.46,-.70,-.50],trim,.015);}
  }else if(kind==='drawstring'){
   box(1.30,1.62,.31,[0,0,0],[plain,plain,accent,plain,front,back],.13);
   for(let i=0;i<13;i++)line([[-.62+i*.103,.77,-.14],[-.60+i*.10,.91,0],[-.62+i*.103,.77,.14]],accent,.018);
   line([[-.60,.84,.05],[-.90,.46,.07],[-.83,-.77,.07],[-.60,-.80,.1]],trim,.025);line([[.60,.84,.05],[.90,.46,.07],[.83,-.77,.07],[.60,-.80,.1]],trim,.025);
  }else if(kind==='duffel'){
   const body=mesh(new THREE.CylinderGeometry(.61,.61,1.85,36,8,false),[plain,accent,accent]);body.rotation.z=Math.PI/2;body.scale.z=.86;
   box(1.2,.57,.07,[0,-.04,.52],front,.08);
   for(const x of [-.53,.53])line([[x,-.43,.35],[x,.47,.32],[x,.91,.06],[x,.46,-.31],[x,-.43,-.35]],dark,.047);
   line([[-.9,.28,-.3],[-.4,1.3,-.43],[.4,1.3,-.43],[.9,.28,-.3]],accent,.035);line([[-.82,.54,.02],[.82,.54,.02]],trim,.016);
  }else{
   box(1.60,1.43,.38,[0,-.15,0],[plain,plain,dark,plain,front,back],.07);
   for(const z of [-.20,.20])line([[-.43,.50,z],[-.40,1.20,z],[.40,1.20,z],[.43,.50,z]],accent,.048);
   line([[-.77,.57,.20],[.77,.57,.20]],trim,.012);
  }
 }else if(kind==='hoodie'){
  const top=torso('long',1,0,1.03);const positions:number[]=[],uv:number[]=[],idx:number[]=[];
  for(let j=0;j<=20;j++)for(let i=0;i<=32;i++){const t=i/32*Math.PI,v=j/20,r=Math.sqrt(Math.max(0,1-v*v));positions.push(.44*Math.cos(t)*r,1.00+.65*v,-.37*Math.sin(t)*r);uv.push(i/32,v);}
  for(let j=0;j<20;j++)for(let i=0;i<32;i++){const a=j*33+i;idx.push(a,a+1,a+33,a+1,a+34,a+33);}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();mesh(g,plain);
  line([[-.43,1.0,.01],[-.39,1.34,.015],[0,1.65,.025],[.39,1.34,.015],[.43,1.0,.01]],accent,.025);
  for(const s of [-1,1])line([[s*.18,.89,.29],[s*.22,.63,.36],[s*.19,.36,.36]],trim,.012);
  box(.83,.43,.045,[0,-.48,.30],plain,.04);
 }else if(kind==='jacket'){const top=torso('long',1,0);zip(top);for(const s of [-1,1])line([[s*.50,-.15,.24],[s*.36,-.50,.29]],trim,.012);}
 else if(kind==='cheer'){torso('tank',.66,.75,.9);skirt();}
 else if(kind==='tracksuit'){const top=torso('long',.69,.85,1.0);zip(top);bottoms(true);}
 else if(kind==='wrestling'){torso('tank',.87,.34,.83);bottoms(false,true);}
 else if(kind==='hockey'){const top=torso('long',1,0,1.14);for(let i=0;i<3;i++)line([[-.055,.72-i*.07,.30],[.055,.67-i*.07,.30]],trim,.009,top);}
 else if(kind==='tennis'){torso('shirt',.66,.68,.91);skirt();}
 else if(kind==='baseball'||kind==='softball'||kind==='cricket'){
  const top=torso('shirt',.72,.91,kind==='softball'?.92:1);bottoms(true);if(kind!=='cricket'){zip(top);for(let i=0;i<6;i++)mesh(new THREE.SphereGeometry(.025,8,6),trim,[.03,.73-i*.27,.31],top);}
 }else{
  const tank=['basketball','lacrosse','track'].includes(kind);const top=torso(tank?'tank':'shirt',kind==='football'?.86:.76,.58,kind==='football'?1.10:kind==='track'?.85:1);
  bottoms(false,kind==='track'||kind==='cycling'||kind==='volleyball');
  if(kind==='cycling')zip(top);
 }
 // Center and normalize all product classes for consistent category previews.
 group.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(group);const size=bounds.getSize(new THREE.Vector3());const center=bounds.getCenter(new THREE.Vector3());group.children.forEach(child=>child.position.sub(center));const s=2.75/Math.max(size.y,size.x*.92);group.scale.setScalar(s);
 return {group,dispose:()=>{geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());fabric.dispose();}};
}

export function productScene(){const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(34,1,.1,40);camera.position.set(0,.1,5.4);camera.lookAt(0,0,0);scene.add(new THREE.HemisphereLight(0xffffff,0x3b3b48,1.4));const key=new THREE.DirectionalLight(0xfff7ef,3.6);key.position.set(-3,4,3);scene.add(key);const rim=new THREE.DirectionalLight(0xffe4e6,2.4);rim.position.set(3,3,-2);scene.add(rim);const fill=new THREE.DirectionalLight(0xdce6ff,.9);fill.position.set(2,-1,4);scene.add(fill);return {scene,camera};}
