export type ProductKind = 'basketball'|'cheer'|'football'|'soccer'|'lacrosse'|'track'|'hoodie'|'jacket'|'backpack'|'drawstring'|'duffel'|'tote'|'baseball'|'softball'|'volleyball'|'hockey'|'wrestling'|'rugby'|'cricket'|'tennis'|'cycling'|'esports'|'tracksuit'|'training';
export type Category = { id:ProductKind; name:string; code:string; group:'Uniforms'|'Outerwear'|'Bags'; line:string; items:string[]; sheet:1|2; cell:number };
export const categories:Category[] = [
 {id:'basketball',name:'Basketball',code:'BB',group:'Uniforms',line:'Own every possession.',items:['Game jerseys','Matching shorts','Reversible options'],sheet:1,cell:0},
 {id:'cheer',name:'Cheer & Dance',code:'CH',group:'Uniforms',line:'Bring the whole squad.',items:['Performance tops','Pleated skirts','Practice sets'],sheet:1,cell:1},
 {id:'football',name:'American Football',code:'FB',group:'Uniforms',line:'Built for every down.',items:['Game jerseys','Football pants','Flag & 7-on-7 kits'],sheet:1,cell:2},
 {id:'soccer',name:'Soccer',code:'SC',group:'Uniforms',line:'One club. One identity.',items:['Match jerseys','Shorts','Goalkeeper kits'],sheet:1,cell:3},
 {id:'lacrosse',name:'Lacrosse',code:'LX',group:'Uniforms',line:'Fast game. Bold look.',items:['Game jerseys','Shorts','Training pinnies'],sheet:1,cell:4},
 {id:'track',name:'Track & Field',code:'TF',group:'Uniforms',line:'Made for your next best.',items:['Race singlets','Running shorts','Training layers'],sheet:1,cell:5},
 {id:'hoodie',name:'Hoodies',code:'HD',group:'Outerwear',line:'Team spirit. Off the field.',items:['Pullover hoodies','Team graphics','Warm-up layers'],sheet:1,cell:6},
 {id:'jacket',name:'Sublimated Jackets',code:'JK',group:'Outerwear',line:'Your identity, all over.',items:['Full-zip jackets','Sublimated patterns','Team warm-ups'],sheet:1,cell:7},
 {id:'backpack',name:'Backpacks',code:'BP',group:'Bags',line:'Carry your team with you.',items:['Team backpacks','Front-pocket options','Coordinated graphics'],sheet:1,cell:8},
 {id:'drawstring',name:'Drawstring Bags',code:'DS',group:'Bags',line:'Grab it. Get going.',items:['Cinch sacks','Drawcord closures','Custom team prints'],sheet:1,cell:9},
 {id:'duffel',name:'Duffel Bags',code:'DF',group:'Bags',line:'Ready for the road game.',items:['Sports duffels','Carry handles','Team graphics'],sheet:1,cell:10},
 {id:'tote',name:'Tote & Kit Bags',code:'KT',group:'Bags',line:'Everything your team needs.',items:['Team totes','Equipment carry bags','Custom graphics'],sheet:1,cell:11},
 {id:'baseball',name:'Baseball',code:'BS',group:'Uniforms',line:'Make the diamond yours.',items:['Button-front jerseys','Baseball pants','Club apparel'],sheet:2,cell:0},
 {id:'softball',name:'Softball',code:'SB',group:'Uniforms',line:'A look for your lineup.',items:['Game jerseys','Softball pants','Team apparel'],sheet:2,cell:1},
 {id:'volleyball',name:'Volleyball',code:'VB',group:'Uniforms',line:'Rise to every point.',items:['Fitted jerseys','Performance shorts','Warm-up tops'],sheet:2,cell:2},
 {id:'hockey',name:'Hockey',code:'HK',group:'Uniforms',line:'Own your ice.',items:['Long-sleeve jerseys','Practice tops','Off-ice apparel'],sheet:2,cell:3},
 {id:'wrestling',name:'Wrestling',code:'WR',group:'Uniforms',line:'Step onto the mat as one.',items:['Singlets','Two-piece options','Warm-up sets'],sheet:2,cell:4},
 {id:'rugby',name:'Rugby',code:'RG',group:'Uniforms',line:'For the full eighty.',items:['Rugby jerseys','Match shorts','Club apparel'],sheet:2,cell:5},
 {id:'cricket',name:'Cricket',code:'CK',group:'Uniforms',line:'Club colors. Every innings.',items:['Match shirts','Cricket trousers','Training kits'],sheet:2,cell:6},
 {id:'tennis',name:'Tennis & Pickleball',code:'TN',group:'Uniforms',line:'A new court standard.',items:['Performance polos','Skorts & shorts','Club apparel'],sheet:2,cell:7},
 {id:'cycling',name:'Cycling',code:'CY',group:'Uniforms',line:'Wear the miles together.',items:['Cycling jerseys','Cycling shorts','Club kits'],sheet:2,cell:8},
 {id:'esports',name:'Esports',code:'ES',group:'Uniforms',line:'Your squad. Your signature.',items:['Team jerseys','Player shirts','Event apparel'],sheet:2,cell:9},
 {id:'tracksuit',name:'Tracksuits',code:'TS',group:'Outerwear',line:'From warm-up to walk-in.',items:['Zip jackets','Matching trousers','Team sets'],sheet:2,cell:10},
 {id:'training',name:'Training & Teamwear',code:'TR',group:'Outerwear',line:'Every day is a team day.',items:['Performance tees','Training shorts','Staff teamwear'],sheet:2,cell:11},
];
export type Design = { id:number;name:string; motif:string; primary:string; accent:string; trim:string; texture?:string };
const designNames=[['Apex','chevron'],['Velocity','diagonal'],['Heritage','stripes'],['Afterburn','gradient'],['Division','split'],['Contour','curves'],['Pinstripe','pinstripe'],['Pulse','zigzag'],['Impact','triangles'],['Horizon','hoops'],['Essential','solid'],['Terrain','camo'],['Lightning','bolt'],['Prism','shards'],['Tidal','waves'],['Gridline','grid'],['Triple Threat','slashes'],['Shield','yoke'],['Eclipse','fade'],['Legacy','sash'],['Halftone','dots'],['Flux','angles'],['Varsity','border'],['Stadium','two-tone']];
const palettes=[['#17191d','#ed243c','#f5f5f1'],['#f0eee8','#e9273d','#191a1e'],['#172b53','#367bde','#ffffff'],['#0c3530','#38b484','#f8f4de'],['#321929','#c94c83','#ffffff'],['#25252c','#f0ae37','#f7f3e8']];
export const designs:Design[]=designNames.map(([name,motif],i)=>({id:i+1,name,motif,primary:palettes[Math.floor(i/4)%palettes.length][0],accent:palettes[Math.floor(i/4)%palettes.length][1],trim:palettes[Math.floor(i/4)%palettes.length][2]}));
export const colorways=[{name:'Lucky red',primary:'#17191d',accent:'#ed243c',trim:'#ffffff'},{name:'Royal blue',primary:'#15243e',accent:'#4285ec',trim:'#ffffff'},{name:'Forest green',primary:'#0e3029',accent:'#45bc8d',trim:'#f8f4de'},{name:'Away white',primary:'#f0eee8',accent:'#ed243c',trim:'#191a1e'}];
export const designCode=(category:Category,design:Design)=>`LA-${category.code}-${String(design.id).padStart(2,'0')}`;
