import type { Category, Design } from './catalog';
export const mockupPath=(category:Category,design:Design,size:320|640=640)=>`/mockups/${category.id}/${String(design.id).padStart(2,'0')}-${size}.avif`;
export const templatePath=(category:Category)=>`/templates/${category.id}.webp`;
