import * as THREE from 'three';
import type { Category } from './catalog';

export type FabricProfile = 'performance-knit' | 'soft-fleece' | 'woven-shell';
/** Small, deterministic textile maps. The yarn relief is lighting-driven, not printed dots. */
export function createFabric(category: Category) {
  const profile: FabricProfile = category.group === 'Bags' || category.id === 'jacket'
    ? 'woven-shell' : category.id === 'hoodie' || category.id === 'tracksuit'
      ? 'soft-fleece' : 'performance-knit';
  const size = 128;
  const heights = new Float32Array(size * size);
  const normal = new Uint8Array(size * size * 4);
  const roughness = new Uint8Array(size * size * 4);
  const tau = Math.PI * 2;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const u = x / 8, v = y / 8;
    const warp = Math.cos(u * tau), weft = Math.cos(v * tau);
    const over = (Math.floor(u) + Math.floor(v)) % 2 === 0;
    const knit = Math.cos((u + .22 * Math.sin(v * tau)) * tau) * .35 + Math.cos(v * tau) * .12;
    const weave = (over ? warp * .34 + weft * .12 : weft * .34 + warp * .12);
    const fiber = Math.sin(x * tau / 2) * Math.cos(y * tau / 4) * .025;
    heights[y * size + x] = (profile === 'performance-knit' ? knit : weave) + fiber;
  }
  const at = (x: number, y: number) => heights[((y + size) % size) * size + (x + size) % size];
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = (y * size + x) * 4;
    const dx = (at(x - 1, y) - at(x + 1, y)) * 1.3;
    const dy = (at(x, y - 1) - at(x, y + 1)) * 1.3;
    const n = new THREE.Vector3(dx, dy, 1).normalize();
    normal.set([Math.round((n.x * .5 + .5) * 255), Math.round((n.y * .5 + .5) * 255), Math.round((n.z * .5 + .5) * 255), 255], i);
    const r = Math.round((profile === 'soft-fleece' ? .94 : .84) * 255 + at(x, y) * 17);
    roughness.set([r, r, r, 255], i);
  }
  const map = (data: Uint8Array) => {
    const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(profile === 'woven-shell' ? 7 : 10, profile === 'woven-shell' ? 9 : 13);
    texture.generateMipmaps = true;
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.anisotropy = 4;
    texture.needsUpdate = true;
    return texture;
  };
  const normalMap = map(normal), roughnessMap = map(roughness);
  const material = (parameters: THREE.MeshPhysicalMaterialParameters = {}) => {
    const cloth = new THREE.MeshPhysicalMaterial({
      roughness: 1, metalness: 0, normalMap, roughnessMap,
      normalScale: new THREE.Vector2(profile === 'soft-fleece' ? .2 : .34, profile === 'soft-fleece' ? .2 : .34),
      sheen: profile === 'soft-fleece' ? .85 : .48,
      sheenRoughness: .85, sheenColor: new THREE.Color('#dddce0'),
      side: THREE.DoubleSide, ...parameters,
    });
    cloth.userData.fabricProfile = profile;
    return cloth;
  };
  return { material, dispose: () => { normalMap.dispose(); roughnessMap.dispose(); } };
}
