# Lucky Athletics project instructions

- This is an existing React + TypeScript + Vite project hosted on Netlify. Preserve its stack and conventions.
- Scope: realistic finished-product design previews across every category, and attractive on-brand homepage category cards.
- Use the existing deterministic template-based renderer and responsive AVIF outputs. These are rendered 3D-style images, not interactive 3D models.
- Source assets: public/templates/products-1.png and products-2.png; design definitions: lib/catalog.ts and lib/design-texture.ts; shared rendering: lib/mockup-renderer.ts.
- Build generates public/mockups and cropped product templates. Do not commit generated images or dist; retain both PNG source atlases.
- Preserve all 24 categories and the existing 24 designs per category unless explicitly asked to change the catalog. Preserve modal navigation, color previews, filters, design codes, focus behavior and contact links.
- Follow ADDING-DESIGNS.md for new patterns and templates. Raster artwork uses the optional texture field and should not be recolored automatically.
- Keep the red/black/white visual identity. Verify layouts at phone and desktop widths when browser preview is available.
- Use Node 24 and pnpm 11.25.0. Install with pnpm install --frozen-lockfile. Validate with pnpm build, pnpm check, pnpm verify:mockups and pnpm verify:interactions.
- Netlify build command is pnpm run build; publish directory is dist. Keep netlify.toml.
- Do not claim that deployment or browser testing succeeded without observing it. Do not add credentials to the repository.
